//
//  ViewController.swift
//  YTDemo-Simulator-3.0
//
//  Created by Peter Shaburov on 4/12/19.
//  Copyright © 2019 Peter Shaburov. All rights reserved.
//

import UIKit
import FirebaseDatabase
import Firebase
class ViewController: UIViewController {
    
    //get this from the database also
    var listOfAllGroups = ["Youtube", "Russians"]
    var firsts: String?
    var grouper: String?
    var counter: Int?
    var current: Int?
    
    let videoList: [String]  = []
    override func viewDidLoad() {
        super.viewDidLoad()
        counter = listOfAllGroups.count - 1
        current = 0
        timer()
        timerDeletion()
    }
    func timer() {
        var gameTimer: Timer?
        gameTimer = Timer.scheduledTimer(timeInterval: 3600, target: self, selector: #selector(runTimedCode), userInfo: nil, repeats: true)

    }
    @objc func runTimedCode() {
        
        print("Sorted: \(Date().timeIntervalSince1970)")
        fetchVideoList(group: listOfAllGroups[0])
    }

    func timerDeletion() {
        var gameTimer: Timer?
        gameTimer = Timer.scheduledTimer(timeInterval: 86200, target: self, selector: #selector(runTimedCodeDeletion), userInfo: nil, repeats: true)
    }
    
    @objc func runTimedCodeDeletion() {
        print("Sorted: \(Date().timeIntervalSince1970)")
        deleteDataLinks()

    }
    
    var first: [(key: String, value: Int)] = []
    
    
    func orderTheLinks(links: [String]) {
        var counts:[String:Int] = [:]
        let mutableLinks = links
        for item in mutableLinks {
            counts[item] = (counts[item] ?? 0) + 1
        }
        writeData(links:counts)
    }
    
    func getYoutubeId(youtubeUrl: String) -> String? {
        return URLComponents(string: youtubeUrl)?.queryItems?.first(where: { $0.name == "v" })?.value
    }
    
    func writeData(links: [String:Int]) {
        let youtuberef = Database.database().reference().child(firsts!)
        first = links.sorted { $0.1 > $1.1 }

        if first.count < 20 {
            for i in 0...first.count - 1 {
                youtuberef.childByAutoId().setValue("https://www.youtube.com/watch?v=" + getYoutubeId(youtubeUrl: first[i].key)!)
            }
        } else {
            for i in 0...20 {
                youtuberef.childByAutoId().setValue("https://www.youtube.com/watch?v=" + getYoutubeId(youtubeUrl: first[i].key)!)
            }
        }
        if current == counter {
            
        }
        if current != counter {
            current = current! + 1
            fetchVideoList(group: listOfAllGroups[current!])
        }
    }
    
    func deleteData() {
        let youtuberef = Database.database().reference().child(firsts!)
        youtuberef.removeValue()
    }
    
    func fetchVideoList(group: String) {
        firsts = group + "First"
        grouper = group
        if group == "Youtube" {
            firsts = "First"
        }
        deleteData()
      
        self.observeFirebase(stringer: grouper!) { [unowned self] (runData) in
            if self.links.count > 1 {
            self.orderTheLinks(links: self.links)
            }
        }

        
    }
    
    var links: [String] = []
    func observeFirebase(stringer: String, completion: @escaping ([String:AnyObject]?) -> ()) {
        links = []
        let ref = Database.database().reference().child(stringer)
        ref.observeSingleEvent(of: .value, with: { (snapshot) in
            let dataRun = snapshot.value as?  [String:AnyObject]
          
            for (key, _) in dataRun! {
                self.links.append(dataRun![key]!["link"] as! String)
            }
            completion((dataRun))
        })
    }
    
    
    var shiftMove: [String] = []
    func observeFirebases(stringer: String, completion: @escaping ([String:AnyObject]?) -> ()) {
        links = []
        shiftMove = []
        let ref = Database.database().reference().child(stringer)
        ref.observeSingleEvent(of: .value, with: { (snapshot) in
            let dataRun = snapshot.value as?  [String:AnyObject]
            
            for (key, _) in dataRun! {
                self.shiftMove.append(dataRun![key] as! String)
            }
            completion((dataRun))
        })
    }
    
    
  
    func deleteDataLinks() {
        self.observeFirebases(stringer: "RussiansFirst") { [unowned self] (runData) in
             if self.shiftMove.count > 1 {
                self.doSomething(links: self.shiftMove)
            }
        }
    }
    func doSomething(links: [String]) {
        print(links)
        let youtuberef = Database.database().reference().child("Russians")
        youtuberef.removeValue()
        
        let youtubeRefFirst =  Database.database().reference().child("RussiansFirst")
            for i in 0...shiftMove.count - 1 {
                youtuberef.childByAutoId().child("links").setValue(shiftMove[i])
            }
        
    }
    
    
}

